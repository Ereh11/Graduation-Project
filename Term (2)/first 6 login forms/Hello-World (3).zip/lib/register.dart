import 'package:flutter/material.dart';
//import 'package:dropdownfield/dropdownfield.dart';
import 'main.dart';

void main() => runApp(register());

class register extends StatelessWidget {
  // This widget is the root of your application.
  List<String> country = [
    "Egypt",
    "USA",
    "Canada",
    "india",
    "China"
  ];
  String Country_id;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: register_pag(title: 'Flutter Demo Home Page'),
    );
  }
}

String country_id;
List<String> country = [
  "America",
  "Brazil",
  "Canada",
  "India",
  "Mongalia",
  "USA",
  "China",
  "Russia",
  "Germany"
];

String f_name, l_name, E_Mail, phone, pass, confirm_pass;

class register_pag extends StatelessWidget {
  final String title;
  const register_pag({@required this.title});

  //List<String> country = ["Egypt" , "USA" , "Canada" , "india" , "China"];
//String Country_id;

  get selectedValue => null;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            constraints: BoxConstraints.expand(),
            decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/reg.png"), fit: BoxFit.fill)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(
                height: 290.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 15.0,
                    ),
                    Container(
                        width: 160.0,
                        height: 35.0,
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          onChanged: (value) {
                            f_name = value;
                            print("First Name: " + f_name);
                          },
                          decoration: InputDecoration(labelText: "First Name", border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)), fillColor: Colors.black, prefixIcon: Icon(Icons.person)),
                          cursorColor: Colors.black,
                        )),
                    SizedBox(
                      width: 10.0,
                    ),
                    Container(
                        width: 160.0,
                        height: 35.0,
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          onChanged: (value) {
                            l_name = value;
                            print("Last Name: " + l_name);
                          },
                          decoration: InputDecoration(labelText: "Last Name", border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)), fillColor: Colors.black, prefixIcon: Icon(Icons.person)),
                          cursorColor: Colors.black,
                        )),
                  ])),
              SizedBox(
                height: 15.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 15.0,
                    ),
                    Container(
                        width: 330.0,
                        height: 35.0,
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          onChanged: (value) {
                            E_Mail = value;
                            print("E Mail" + E_Mail);
                          },
                          decoration: InputDecoration(labelText: "E-Mail", border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)), fillColor: Colors.black, prefixIcon: Icon(Icons.mail)),
                          cursorColor: Colors.black,
                        )),
                  ])),
              SizedBox(
                height: 15.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 15.0,
                    ),
                    Container(
                        width: 330.0,
                        height: 35.0,
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          onChanged: (value) {
                            phone = value;
                            print("phone: " + phone);
                          },
                          decoration: InputDecoration(labelText: "Phone", border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)), fillColor: Colors.black, prefixIcon: Icon(Icons.phone)),
                          cursorColor: Colors.black,
                        )),
                  ])),
              SizedBox(
                height: 15.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 15.0,
                    ),
                    Container(
                        width: 330.0,
                        height: 35.0,
                        child: TextFormField(
                          keyboardType: TextInputType.visiblePassword,
                          onChanged: (value) {
                            pass = value;
                            print("Password: " + pass);
                          },
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: "Password",
                            border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)),
                            fillColor: Colors.white,
                            prefixIcon: Icon(Icons.lock),
                            suffixIcon: Icon(Icons.remove_red_eye),
                          ),
                          cursorColor: Colors.black,
                        )),
                  ])),
              SizedBox(
                height: 15.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 15.0,
                    ),
                    Container(
                        width: 330.0,
                        height: 35.0,
                        child: TextFormField(
                          keyboardType: TextInputType.visiblePassword,
                          onChanged: (value) {
                            confirm_pass = value;
                            print("Confirm Password: " + confirm_pass);
                          },
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: "Confirm Password",
                            border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)),
                            fillColor: Colors.white,
                            prefixIcon: Icon(Icons.lock),
                            suffixIcon: Icon(Icons.remove_red_eye),
                          ),
                          cursorColor: Colors.black,
                        )),
                  ])),
              SizedBox(
                height: 15.0,
              ),
              SizedBox(
                height: 15.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 22.0,
                    ),
                    Container(
                        width: 320.0,
                        height: 35.0,
                        child: MaterialButton(
                          onPressed: () {},
                          color: Colors.green,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          child: Text("CREATE AN ACCOUNT", style: TextStyle(color: Colors.white)),
                        ))
                  ])),
            ])));
  }
}
