import 'package:flutter/material.dart';

import 'main.dart';

void main() => runApp(start_pag());

class start_pag extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: new_start_pag(title: 'Flutter Demo Home Page'),
    );
  }
}

class new_start_pag extends StatelessWidget {
  final String title;
  const new_start_pag({@required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Container(constraints: BoxConstraints.expand(), decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/start.png"), fit: BoxFit.fill)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [])));
  }
}
