import 'package:flutter/material.dart';
import 'package:helloworld/new_pass.dart';

import 'main.dart';

void main() => runApp(OTP());

class OTP extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: OPT_page(title: 'Flutter Demo Home Page'),
    );
  }
}

String otp1 = "", otp2 = "", otp3 = "", otp4 = "", otp5 = "", otp6 = "", temp = "";

class OPT_page extends StatelessWidget {
  final String title;
  const OPT_page({@required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            constraints: BoxConstraints.expand(),
            decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/OTP.png"), fit: BoxFit.fill)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(
                height: 385.0,
              ),
              Container(
                  width: 430.0,
                  height: 30.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 110.0,
                    ),
                    Text(
                      E_mail,
                      style: TextStyle(color: Colors.black54),
                    ),
                  ])),
              SizedBox(
                height: 15.0,
              ),
              Container(
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SizedBox(
                  width: 22.0,
                ),
                Container(
                  width: 40.0,
                  height: 40.0,
                  child: TextFormField(
                      keyboardType: TextInputType.phone,
                      onChanged: (_otp1) {
                        otp1 = _otp1;
                        print(otp1);
                      },
                      decoration: InputDecoration(border: OutlineInputBorder(), fillColor: Colors.black),
                      cursorColor: Colors.black),
                ),
                SizedBox(
                  width: 15.0,
                ),
                Container(
                  width: 40.0,
                  height: 40.0,
                  child: TextFormField(
                      keyboardType: TextInputType.phone,
                      onChanged: (_otp2) {
                        otp2 = _otp2;
                        print(otp2);
                      },
                      decoration: InputDecoration(border: OutlineInputBorder(), fillColor: Colors.black),
                      cursorColor: Colors.black),
                ),
                SizedBox(
                  width: 15.0,
                ),
                Container(
                  width: 40.0,
                  height: 40.0,
                  child: TextFormField(
                      keyboardType: TextInputType.phone,
                      onChanged: (_otp3) {
                        otp3 = _otp3;
                        print(otp3);
                      },
                      decoration: InputDecoration(border: OutlineInputBorder(), fillColor: Colors.black),
                      cursorColor: Colors.black),
                ),
                SizedBox(
                  width: 15.0,
                ),
                Container(
                  width: 40.0,
                  height: 40.0,
                  child: TextFormField(
                      keyboardType: TextInputType.phone,
                      onChanged: (_otp4) {
                        otp4 = _otp4;
                        print(otp4);
                      },
                      decoration: InputDecoration(border: OutlineInputBorder(), fillColor: Colors.black),
                      cursorColor: Colors.black),
                ),
                SizedBox(
                  width: 15.0,
                ),
                Container(
                  width: 40.0,
                  height: 40.0,
                  child: TextFormField(
                      keyboardType: TextInputType.phone,
                      onChanged: (_otp5) {
                        otp5 = _otp5;
                        print(otp5);
                      },
                      decoration: InputDecoration(border: OutlineInputBorder(), fillColor: Colors.black),
                      cursorColor: Colors.black),
                ),
                SizedBox(
                  width: 15.0,
                ),
                Container(
                  width: 40.0,
                  height: 40.0,
                  child: TextFormField(
                      keyboardType: TextInputType.phone,
                      onChanged: (_otp6) {
                        otp6 = _otp6;
                        print(otp6);
                      },
                      decoration: InputDecoration(border: OutlineInputBorder(), fillColor: Colors.black),
                      cursorColor: Colors.black),
                ),
              ])),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  padding: EdgeInsets.fromLTRB(60, 0, 0, 0),
                  width: 280.0,
                  child: MaterialButton(
                    onPressed: () {},
                    child: Text(temp, style: TextStyle(color: Colors.redAccent)),
                  )),
              SizedBox(
                height: 20.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 82.0,
                    ),
                    Container(
                        width: 200.0,
                        child: MaterialButton(
                          onPressed: () {
                            if (otp1 != "" && otp2 != "" && otp3 != "" && otp4 != "" && otp5 != "" && otp6 != "") {
                              if (true) //otp validation true value or not !!!
                              {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => new_pass()),
                                );
                              } else {
                                temp = "Check The OTP Code again !!!";
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => OTP()),
                                );
                              }
                              print("Why !!!");
                            } else {
                              temp = "Check The OTP Code again !!!";
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => OTP()),
                              );
                            }
                          },
                          color: Colors.green,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          child: Text("     VERIFY & PROCEED     ", style: TextStyle(color: Colors.white)),
                        )),
                  ])),
            ])));
  }
}
