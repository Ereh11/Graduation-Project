import 'package:flutter/material.dart';
import 'package:helloworld/otp.dart';

import 'main.dart';

void main() => runApp(gmail_pag());

class gmail_pag extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: my_gmail_pag(title: 'Flutter Demo Home Page'),
    );
  }
}

String temp = "";

class my_gmail_pag extends StatelessWidget {
  final String title;

  const my_gmail_pag({@required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            constraints: BoxConstraints.expand(),
            decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/Gmail.png"), fit: BoxFit.fill)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(
                height: 445.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 30.0,
                    ),
                    Container(
                        width: 300.0,
                        height: 40.0,
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          onChanged: (_email) {
                            E_mail = _email;
                            print(E_mail);
                          },
                          decoration: InputDecoration(labelText: "E-Mail", border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)), fillColor: Colors.black, prefixIcon: Icon(Icons.email)),
                          cursorColor: Colors.black,
                        )),
                  ])),
              Container(
                  padding: EdgeInsets.fromLTRB(60, 0, 0, 0),
                  width: 230.0,
                  child: MaterialButton(
                    onPressed: () {},
                    child: Text(temp, style: TextStyle(color: Colors.redAccent)),
                  )),
              SizedBox(
                height: 45.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 108.0,
                    ),
                    Container(
                        width: 150.0,
                        child: MaterialButton(
                          onPressed: () {
                            if (E_mail != "") {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => OTP()),
                              );
                            } else {
                              temp = "Please Enter the Gmail !";
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => gmail_pag()),
                              );
                            }
                          },
                          color: Colors.green,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          child: Text("SEND", style: TextStyle(color: Colors.white)),
                        )),
                  ])),
            ])));
  }
}
