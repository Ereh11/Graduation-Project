import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'gmail_pag.dart';
import 'new_pass.dart';
import 'otp.dart';
import 'register.dart';
import 'start_pag.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

String username, login_pass;
String E_mail = "";

class MyHomePage extends StatelessWidget {
  final String title;
  const MyHomePage({@required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          constraints: BoxConstraints.expand(),
          decoration: BoxDecoration(image: DecorationImage(image: AssetImage("images/login.png"), fit: BoxFit.fill)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 240.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 30.0,
                    ),
                    Container(
                        width: 300.0,
                        height: 40.0,
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          onChanged: (value) {
                            username = value;
                            print("username: " + username);
                          },
                          decoration: InputDecoration(labelText: "Username", border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)), fillColor: Colors.black, prefixIcon: Icon(Icons.email)),
                          cursorColor: Colors.black,
                        )),
                  ])),
              SizedBox(
                height: 15.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 30.0,
                    ),
                    Container(
                        width: 300.0,
                        height: 40.0,
                        child: TextFormField(
                          keyboardType: TextInputType.visiblePassword,
                          onChanged: (value) {
                            login_pass = value;
                            print("Password: " + login_pass);
                          },
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: "Password",
                            border: OutlineInputBorder(borderSide: const BorderSide(color: Colors.green, width: 2.0), borderRadius: BorderRadius.circular(25.0)),
                            fillColor: Colors.white,
                            prefixIcon: Icon(Icons.lock),
                            suffixIcon: Icon(Icons.remove_red_eye),
                          ),
                          cursorColor: Colors.black,
                        )),
                  ])),
              Container(
                  padding: EdgeInsets.fromLTRB(60, 0, 0, 0),
                  width: 190.0,
                  child: MaterialButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => gmail_pag()),
                      );
                    },
                    child: Text("Forget Password!", style: TextStyle(color: Colors.black54)),
                  )),
              SizedBox(
                height: 6.5,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 108.0,
                    ),
                    Container(
                        width: 150.0,
                        child: MaterialButton(
                          onPressed: () {
                            if (username != "" && login_pass != "") {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => gmail_pag()),
                              );
                            }
                          },
                          color: Colors.green,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          child: Text("Login", style: TextStyle(color: Colors.white)),
                        )),
                  ])),
              SizedBox(
                height: 180.0,
              ),
              Container(
                  width: 430.0,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: 22.0,
                    ),
                    Container(
                        width: 320.0,
                        height: 40.0,
                        child: MaterialButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => register_pag()),
                            );
                          },
                          color: Colors.green,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          child: Text("Register", style: TextStyle(color: Colors.white)),
                        ))
                  ])),
            ],
          )),
    );
  }
}
